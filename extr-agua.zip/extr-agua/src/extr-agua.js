// Cargar las librerías
const { log } = require("console"); // Para mensajes por consola (terminal)
const fs = require("fs"); // Para lecturas/escrituras de archivos. Nativa de node
const path = require("path"); // Para acceso a directorios. Nativa de node
const XLSX = require("xlsx"); // Para manejo de archivos Excel (XLS, XLSX)
const createCsvWriter = require('csv-writer').createObjectCsvWriter; // Para generar archivo CSV

// Definir archivo de origen
const xlsx = path.resolve("src/nva-base-agua-2019.xlsx"); // Obtiene la ruta absoluta al archivo

// Definir filtros
const regiones = ["Coquimbo", "Valparaíso"];

// Leer los datos del archivo origen
var buf = fs.readFileSync(xlsx); // Leer archivo. Permite almacenar el archivo en memoria
var wb = XLSX.read(buf, { type: 'buffer' }); // Interpreta el formato Excel desde la lectura
var hoja = wb.Sheets["Hoja1"]; // Accede a una hoja por su nombre, "Hoja1" por defecto al existir solo una
var hoja_json = XLSX.utils.sheet_to_json(hoja); // Convierte la hora a formato JSON

// Muestra por consola el contenido de la primera fila
log("Encabezados en Hoja", hoja_json[1]);

// Preparar variable donde se mantendrá la transformación, en formato JSON
var output_data = {} // Objeto JSON "vacío", es decir sin datos

// Ciclo para recorrer todas las filas de la hoja
for (let idx = 0; idx < hoja_json.length; idx++) {

  let region_hoja = hoja_json[idx].Región; // Obtiene el valor de la columna REGION

  // Validar condición que la fila leida coincida con los filtros requeridos.

  if (region_hoja == regiones > -1) {

    // Obtener el registro desde la variable donde se mantendrá la transformación
    let data_region = output_data[region_hoja];

    if (data_region) {
      // Si existe el registro, se aumentan los contadores
      data_region["Año"] = hoja_json[idx]["Año"];
      data_region['Unidades'] = hoja_json[idx]['Unidades'];
      data_region['Aguas Superficiales (1)/Surface water'] = hoja_json[idx]['Aguas Superficiales (1) / Surface water'];
      data_region['Aguas Subterráneas (2) / Groundwater'] = hoja_json[idx]['Aguas Subterráneas (2) / Groundwater'];
      data_region['Aguas adquiridas a terceros (3) / Purchased water'] = hoja_json[idx]['Aguas adquiridas a terceros (3) / Purchased water'];
    } else {
      // Al no existir registro, se establece los contadores
      data_region = {};
      data_region["Año"] = hoja_json[idx]["Año"];
      data_region['Unidades'] = hoja_json[idx]['Unidades'];
      data_region['Aguas Superficiales (1)/Surface water'] = hoja_json[idx]['Aguas Superficiales (1) / Surface water'];
      data_region['Aguas Subterráneas (2) / Groundwater'] = hoja_json[idx]['Aguas Subterráneas (2) / Groundwater'];
      data_region['Aguas adquiridas a terceros (3) / Purchased water'] = hoja_json[idx]['Aguas adquiridas a terceros (3) / Purchased water'];
    }

    // Se almacena en la variable la información procesada
    output_data[region_hoja] = data_region;
  }
}

// Muestra por consola el contenido de información procesada
log("Data de Salida", output_data);

// Definir archivo de salida (JSON)
const json_file = path.resolve("src/extraccion-agua.json"); //crear ruta de exportacion a JSON

// Guardar en JSON los datos transformados 
fs.writeFileSync(json_file, JSON.stringify(output_data)); //stringify lo convierte a texto


//Generar archivo CSV

var output_csv = [] // Objeto Array vacío

// Ciclo para obtener los datos procesados de cada comuna
for (let n = 0; n < regiones.length; n++) {
  let nombre_region = regiones[n];
  datos_region = output_data[nombre_region];
  output_csv.push({
    "Año": datos_region["Año"],
    "Unidades": datos_region["Unidades"],
    "Aguas Superficiales (1)/Surface water": datos_region["Aguas Superficiales (1)/Surface water"],
    "Aguas Subterráneas (2) / Groundwater": datos_region["Aguas Subterráneas (2) / Groundwater"],
    "Aguas adquiridas a terceros (3) / Purchased water": datos_region["Aguas adquiridas a terceros (3) / Purchased water"],
  })
}

log("Salida para CSV", output_csv);

// Definir archivo de salida (CSV)
const csv_file = path.resolve("src/extraccion-agua.csv");

// Configurar objeto de escritura CSV, indicando los nombres de columnas como encabezados
const csvWriter = createCsvWriter({
  path: csv_file,
  header: [
    { id: "Región", title: "Región" },
    { id: "Año", title: "Año" },
    { id: "Unidades", title: "Unidades" },
    { id: "Aguas Superficiales (1)/Surface water", title: "Aguas Superficiales (1)/Surface water" },
    { id: "Aguas Subterráneas (2) / Groundwater", title: "Aguas Subterráneas (2) / Groundwater" },
    { id: "Aguas adquiridas a terceros (3) / Purchased water", title: "Aguas adquiridas a terceros (3) / Purchased water" },
  ]
});

// Escribir el archivo de salida CSV
csvWriter.writeRecords(output_csv).then(() => {
  log("Archivo CSV escrito!!!");
}).catch((error) => {
  log("Error al escribir el archivo CSV", error);
})

